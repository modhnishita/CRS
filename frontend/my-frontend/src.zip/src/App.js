import React from "react";

import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Questionnaire from "./Questionnaire";
import Result from "./Result";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Questionnaire />} />
        <Route path="/result" element={<Result />} />
      </Routes>
    </Router>
  );
}

export default App;

