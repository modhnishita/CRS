import React from "react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Questionnaire() {
  const [questions, setQuestions] = useState([]);
  const [responses, setResponses] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://127.0.0.1:5000/questions").then((response) => {
      setQuestions(response.data);
    });
  }, []);

  const handleSubmit = () => {
    const answers = questions.map((q, index) => responses[index] || "");
    axios
      .post("http://127.0.0.1:5000/recommend", { responses: answers })
      .then((response) => {
        navigate("/result", { state: { recommendedCourse: response.data.recommended_course } });
      });
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Course Recommendation</h1>
      {questions.map((q, index) => (
        <div key={index} style={{ marginBottom: "15px" }}>
          <p><strong>{q.question}</strong></p>
          {q.options.map((option, i) => (
            <label key={i} style={{ display: "block" }}>
              <input
                type="radio"
                name={`question-${index}`}
                value={option}
                onChange={() => setResponses({ ...responses, [index]: option })}
              />
              {option}
            </label>
          ))}
        </div>
      ))}
      <button onClick={handleSubmit} style={{ marginTop: "20px", padding: "10px 20px" }}>Submit</button>
    </div>
  )
};

export default Questionnaire;