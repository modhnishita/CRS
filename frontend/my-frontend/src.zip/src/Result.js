import React from "react";
import { useLocation } from 'react-router-dom';


function Result() {
  const location = useLocation();
  const { recommendedCourse } = location.state || {};  // This is your passed data

  return (
    <div style={{ padding: "20px" }}>
      <h1>Recommended Course</h1>
      {recommendedCourse ? (
        <p>{recommendedCourse}</p>
      ) : (
        <p>No recommendation available</p>
      )}
    </div>
  );
}

export default Result; 